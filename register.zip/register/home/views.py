from django.shortcuts import render
from django.http import HttpResponse
from home.models import Register

# Create your views here.

def index(request):
    return render(request,'Register.html')

def submit_form(request):
    if request.method=="POST":
        First_Name=request.POST['First_Name']
        Middle_Name=request.POST['Middle_Name']
        Last_Name=request.POST['Last_Name']
        Phone_Number=request.POST['Phone_Number']
        College_Name=request.POST['College_Name']
        Home_Address=request.POST['Home_Address']
        Gender=request.POST['Gender']
        Area_Prog=request.POST.get('Programing','off')
        Area_java=request.POST.get('JAVA','off')
        Area_python=request.POST.get('PYTHON','off')
        Area_django=request.POST.get('DJANGO','off')
        Area_html=request.POST.get('HTML','off')
        AOI=[]
        if Area_Prog=="Programing":
            AOI.append(Area_Prog)
        if Area_java=="JAVA":
            AOI.append(Area_java)
        if Area_python=="PYTHON":
            AOI.append(Area_python)
        if Area_django=="DJANGO":
            AOI.append(Area_django)
        if Area_html=="HTML":
            AOI.append(Area_html)

        print(First_Name,Middle_Name,Last_Name,Phone_Number,College_Name,Home_Address,Gender,*AOI)
        Register(First_Name=First_Name,Middle_Name=Middle_Name, Last_Name=Last_Name,Phone_Number=Phone_Number,College_Name=College_Name,Home_Address=Home_Address,Gender=Gender,Area_of_Interest=AOI).save()
        msg="Form submitted Sucessfully"
        return render(request,'Register.html',{'msg':msg})
    else:
        return HttpResponse("<h1>404 - not found</h1>")